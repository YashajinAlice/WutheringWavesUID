"use client"

import { Search, Bell, User } from "lucide-react"
import { useState } from "react"

export default function Header() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <header className="bg-gray-900 text-white sticky top-0 z-50 border-b border-gray-800">
      <div className="px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2 font-bold text-lg">
            <div className="w-8 h-8 bg-cyan-400 rounded flex items-center justify-center text-gray-900">库</div>
            <span>库街区</span>
          </div>

          <nav className="flex gap-6 text-sm">
            <a href="#" className="hover:text-cyan-400 transition">
              库街区
            </a>
            <a href="#" className="hover:text-cyan-400 transition">
              战双帕弥苏
            </a>
            <a href="#" className="hover:text-cyan-400 transition">
              鸣潮
            </a>
            <a href="#" className="hover:text-cyan-400 transition">
              更新公告
            </a>
          </nav>
        </div>

        <div className="flex items-center gap-4 flex-1 max-w-xs mx-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="搜索"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 text-white pl-10 pr-4 py-2 rounded text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400"
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="bg-cyan-400 text-gray-900 px-4 py-2 rounded font-semibold text-sm hover:bg-cyan-300 transition">
            发表
          </button>
          <Bell className="w-5 h-5 cursor-pointer hover:text-cyan-400 transition" />
          <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-600 transition">
            <User className="w-5 h-5" />
          </div>
        </div>
      </div>
    </header>
  )
}
