"use client"
import { useState } from "react"
import PostCard from "./post-card"

export default function Feed() {
  const [posts] = useState([
    {
      id: 1,
      author: "绯狱",
      avatar: "/user-avatar.jpg",
      time: "2025-04-29 10:44",
      category: "活动",
      title: "【有奖活动】玩家参与大剧情活动分享截图送周边",
      content: "参与大剧情活动，分享你的精彩时刻，赢取独家周边！",
      image: "/game-screenshot.jpg",
      likes: 49768,
      comments: 896,
      views: 10000,
      tags: ["活动", "周边"],
    },
    {
      id: 2,
      author: "Qixuanxxx",
      avatar: "/user-avatar-2.jpg",
      time: "2025-04-29 09:30",
      category: "讨论",
      title: "一起聊聊你的合作",
      content: "分享你最喜欢的游戏合作角色和故事！",
      image: "/game-characters.jpg",
      likes: 12345,
      comments: 456,
      views: 5000,
      tags: ["讨论", "角色"],
    },
    {
      id: 3,
      author: "绯狱",
      avatar: "/user-avatar-3.jpg",
      time: "2025-04-29 08:15",
      category: "公告",
      title: "【开放测试】激情版本专属测试服务器上线",
      content: "新版本测试服务器现已开放，欢迎参与测试！",
      image: "/game-update.jpg",
      likes: 8765,
      comments: 234,
      views: 3000,
      tags: ["公告", "测试"],
    },
  ])

  return (
    <div className="flex-1 max-w-2xl">
      <div className="space-y-4">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  )
}
