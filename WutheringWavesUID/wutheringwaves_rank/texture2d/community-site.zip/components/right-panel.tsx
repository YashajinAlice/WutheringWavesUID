"use client"

import { QrCode } from "lucide-react"

export default function RightPanel() {
  const tools = [
    { id: 1, name: "每日卡牌", icon: "🎴" },
    { id: 2, name: "开运签", icon: "🎋" },
    { id: 3, name: "Wiki", icon: "📖" },
    { id: 4, name: "攻略入门", icon: "🗺️" },
    { id: 5, name: "副本详情", icon: "⚔️" },
    { id: 6, name: "主宰交易", icon: "💰" },
    { id: 7, name: "游戏资讯", icon: "📰" },
    { id: 8, name: "活动资讯", icon: "🎉" },
    { id: 9, name: "小区活动", icon: "🎪" },
    { id: 10, name: "攻略资讯", icon: "📚" },
    { id: 11, name: "充值中心", icon: "💳" },
    { id: 12, name: "主宰资源", icon: "⭐" },
  ]

  const topics = [
    { id: 1, title: "#2.7版本万岁#", views: "1.9万", time: "15.8w" },
    { id: 2, title: "#诗篇梦境#", views: "109万", time: "1.3w" },
    { id: 3, title: "#闻名遐迩#", views: "1.4万", time: "15.9w" },
  ]

  return (
    <div className="w-80 space-y-6">
      {/* Tools Section */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="font-bold text-gray-900 mb-4 text-sm">工具箱</h3>
        <div className="grid grid-cols-3 gap-3">
          {tools.map((tool) => (
            <button
              key={tool.id}
              className="flex flex-col items-center gap-2 p-3 rounded-lg hover:bg-gray-50 transition"
            >
              <div className="text-2xl">{tool.icon}</div>
              <span className="text-xs text-gray-600 text-center">{tool.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* QR Code Section */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 flex flex-col items-center">
        <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
          <QrCode className="w-16 h-16 text-gray-400" />
        </div>
        <p className="text-xs text-gray-600 text-center">扫码下载库街区</p>
      </div>

      {/* Trending Topics */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-gray-900 text-sm">推荐话题</h3>
          <a href="#" className="text-xs text-cyan-400 hover:text-cyan-500">
            更多话题 &gt;
          </a>
        </div>
        <div className="space-y-3">
          {topics.map((topic) => (
            <div key={topic.id} className="p-3 rounded-lg hover:bg-gray-50 transition cursor-pointer">
              <div className="font-semibold text-gray-900 text-sm">{topic.title}</div>
              <div className="text-xs text-gray-500 mt-1">
                {topic.views} · {topic.time}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
