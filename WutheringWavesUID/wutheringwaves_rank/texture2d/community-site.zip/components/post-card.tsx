"use client"

import { Heart, MessageCircle, Share2, Eye } from "lucide-react"
import { useState } from "react"

interface Post {
  id: number
  author: string
  avatar: string
  time: string
  category: string
  title: string
  content: string
  image: string
  likes: number
  comments: number
  views: number
  tags: string[]
}

interface PostCardProps {
  post: Post
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(post.likes)

  const handleLike = () => {
    setLiked(!liked)
    setLikeCount(liked ? likeCount - 1 : likeCount + 1)
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition">
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <img src={post.avatar || "/placeholder.svg"} alt={post.author} className="w-10 h-10 rounded-full" />
            <div>
              <div className="font-semibold text-gray-900">{post.author}</div>
              <div className="text-xs text-gray-500">{post.time}</div>
            </div>
          </div>
          <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded">{post.category}</span>
        </div>

        <h3 className="font-bold text-gray-900 mb-2 text-sm">{post.title}</h3>
        <p className="text-gray-700 text-sm mb-3">{post.content}</p>

        {post.image && (
          <img
            src={post.image || "/placeholder.svg"}
            alt={post.title}
            className="w-full h-40 object-cover rounded-lg mb-3"
          />
        )}

        <div className="flex gap-2 mb-3">
          {post.tags.map((tag) => (
            <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between text-gray-500 text-xs border-t border-gray-100 pt-3">
          <div className="flex items-center gap-4">
            <button
              onClick={handleLike}
              className={`flex items-center gap-1 hover:text-red-500 transition ${liked ? "text-red-500" : ""}`}
            >
              <Heart className="w-4 h-4" fill={liked ? "currentColor" : "none"} />
              <span>{likeCount}</span>
            </button>
            <button className="flex items-center gap-1 hover:text-blue-500 transition">
              <MessageCircle className="w-4 h-4" />
              <span>{post.comments}</span>
            </button>
            <button className="flex items-center gap-1 hover:text-gray-700 transition">
              <Eye className="w-4 h-4" />
              <span>{post.views}</span>
            </button>
          </div>
          <button className="hover:text-gray-700 transition">
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
