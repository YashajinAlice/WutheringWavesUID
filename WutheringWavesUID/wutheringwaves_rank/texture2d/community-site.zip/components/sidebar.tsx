"use client"

import { Heart, MessageCircle, Bookmark, Users, FileText, Sparkles } from "lucide-react"

interface SidebarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const menuItems = [
    { id: "follow", label: "关注", icon: Heart },
    { id: "recommend", label: "推荐", icon: Sparkles },
    { id: "eden", label: "伊甸园", icon: MessageCircle },
    { id: "discover", label: "发现", icon: Bookmark },
    { id: "official", label: "官方", icon: FileText },
    { id: "community", label: "同人圈", icon: Users },
    { id: "fanfic", label: "同人文", icon: FileText },
    { id: "cosplay", label: "Cosplay", icon: Sparkles },
  ]

  return (
    <aside className="w-48 bg-white border-r border-gray-200 sticky top-16 h-[calc(100vh-64px)] overflow-y-auto">
      <div className="p-4">
        <h2 className="text-lg font-bold mb-6 text-gray-900">就狂，都别叫</h2>

        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                  activeTab === item.id
                    ? "bg-cyan-100 text-cyan-600 border-l-4 border-cyan-400"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            )
          })}
        </nav>
      </div>
    </aside>
  )
}
