"use client"

import { useState } from "react"
import Header from "@/components/header"
import Sidebar from "@/components/sidebar"
import Feed from "@/components/feed"
import RightPanel from "@/components/right-panel"

export default function Home() {
  const [activeTab, setActiveTab] = useState("feed")

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 flex gap-6 px-6 py-4 max-w-7xl mx-auto">
          <Feed />
          <RightPanel />
        </main>
      </div>
    </div>
  )
}
